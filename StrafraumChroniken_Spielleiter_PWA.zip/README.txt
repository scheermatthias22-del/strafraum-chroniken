# Strafraum‑Chroniken – Spielleiter (Mini‑App / PWA)

## Start (PC)
1) Ordner entpacken
2) `index.html` im Browser öffnen (Chrome/Edge/Firefox)

## Handy (Android)
- Option 1: Dateien in einen Ordner kopieren und `index.html` im Browser öffnen
- Option 2 (besser): auf einen kleinen Webspace legen (z.B. GitHub Pages) und dann im Browser "Zum Startbildschirm hinzufügen"

## Offline
Die App ist PWA‑fähig (Service Worker + Manifest). Nach dem ersten Öffnen sind die Dateien offline verfügbar.

## Datenschutz
Alles bleibt lokal: Session, Log, Notizen. Export als CSV/JSON möglich.
PDFs werden nur lokal angezeigt (Datei bleibt auf dem Gerät).
